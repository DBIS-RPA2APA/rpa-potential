---
title: "Anleitung: CORA-Labeling-Tool"
subtitle: "BPMN-Aktivitäten nach ihrer RPA-Eignung labeln"
---

# Was ist das Labeling-Tool?

Mit dem Labeling-Tool legt ihr fest, welche Aktivitäten eurer BPMN-Prozessmodelle sich mit Robotic Process Automation (RPA) automatisieren lassen und welche der neun RPA-Eignungskriterien nach Bédard et al. sie erfüllen. Diese **Labels** sind die "richtigen Antworten", mit denen CORA später die Einschätzungen der LLMs vergleicht.

Das Tool zeigt das Prozessmodell als Diagramm an. Ihr klickt eine Aktivität an, tragt eure Bewertung ein und speichert am Ende für jedes Modell eine Label-Datei.

Das Tool läuft vollständig in eurem Browser. Eure Prozessmodelle werden **nicht hochgeladen** und nirgendwo gespeichert.

# Was du brauchst

- Einen Computer mit Windows 10/11 (64 Bit), macOS oder Linux.
- Eine Internetverbindung für die Installation. Danach funktioniert das Tool auch offline.
- Den Ordner **labeling-tool** (als ZIP-Datei von eurer Betreuung).
- Eure Prozessmodelle als `.bpmn`-Dateien (z. B. aus Signavio als BPMN 2.0 XML exportiert).

# Schritt 1: Docker installieren

Das Tool läuft mit **Docker**. Docker ist ein Programm, das andere Programme in abgeschlossenen "Containern" ausführt, damit du sonst nichts installieren musst. Für die Arbeit an der Universität (Ausbildung) und für private Zwecke ist **Docker Desktop kostenlos**.

*Wenn du Docker schon für CORA installiert hast, kannst du diesen Schritt überspringen.*

## Windows

1. Öffne <https://www.docker.com/products/docker-desktop/> und klicke auf **Download for Windows**. Wenn du die Wahl hast, nimm **AMD64** (das passt für fast alle Rechner). **ARM64** brauchst du nur bei Geräten mit Snapdragon-Prozessor.
2. Starte die heruntergeladene Datei `Docker Desktop Installer.exe` mit einem Doppelklick.
3. Lass im Installationsfenster die Option **"Use WSL 2 instead of Hyper-V"** angehakt und klicke dich mit **OK** durch.
4. Starte den Computer neu, wenn das Installationsprogramm dich dazu auffordert.
5. Öffne **Docker Desktop** über das Startmenü. Beim ersten Start musst du die Nutzungsbedingungen akzeptieren. Eine Anmeldung bei Docker ist nicht nötig, du kannst diesen Schritt überspringen.
6. Falls Docker meldet, dass **WSL** aktualisiert werden muss: Öffne das Startmenü, tippe `PowerShell`, klicke mit der rechten Maustaste auf **Windows PowerShell** und wähle **Als Administrator ausführen**. Gib dort `wsl --update` ein und drücke Enter. Starte danach Docker Desktop neu.
7. Warte, bis Docker Desktop unten links **"Engine running"** anzeigt (grün).

**Hinweis:** Wenn Docker beim Start meldet, dass die **Virtualisierung** deaktiviert ist, muss sie im BIOS/UEFI des Computers eingeschaltet werden (Stichwort "Intel VT-x" bzw. "AMD-V"). Wie das geht, hängt vom Hersteller ab. Suche nach "Virtualisierung aktivieren" und dem Namen deines Laptops, oder frag deine Betreuung.

## macOS

1. Klicke oben links auf das Apple-Symbol und dann auf **Über diesen Mac**. Steht dort **Apple M1, M2, M3 …**, brauchst du die Version für **Apple Silicon**, bei **Intel** die Version für **Intel**.
2. Lade die passende Version von <https://www.docker.com/products/docker-desktop/> herunter.
3. Öffne die `.dmg`-Datei und ziehe **Docker** in den Ordner **Programme**.
4. Starte Docker aus dem Ordner **Programme**, bestätige die Sicherheitsabfragen und akzeptiere die Nutzungsbedingungen.
5. Warte, bis **"Engine running"** angezeigt wird.

## Linux

Installiere Docker Desktop für Linux oder die Docker Engine mit dem Compose-Plugin nach der Anleitung unter <https://docs.docker.com/engine/install/>.

# Schritt 2: Das Tool starten

1. **Entpacke** die ZIP-Datei `labeling-tool.zip` (Windows: Rechtsklick → **Alle extrahieren**; Mac: Doppelklick). Lege den Ordner an einen einfachen Ort, z. B. `Dokumente\labeling-tool`.
2. Stelle sicher, dass **Docker Desktop läuft** ("Engine running").
3. Öffne ein Terminal **im Ordner labeling-tool**:
   - **Windows:** Öffne den Ordner im Explorer. Klicke oben in die Adressleiste (dort, wo der Pfad steht), tippe `powershell` und drücke Enter.
   - **macOS:** Öffne das Terminal (`Cmd + Leertaste`, `Terminal` tippen, Enter), tippe `cd ` (mit Leerzeichen danach), ziehe den Ordner aus dem Finder in das Terminalfenster und drücke Enter.
4. Gib diesen Befehl ein und drücke Enter:

   ```
   docker compose up --build -d
   ```

   Beim ersten Mal dauert das ein bis zwei Minuten. Fertig ist es, wenn Zeilen mit **Started** oder **Running** erscheinen.
5. Öffne im Browser die Adresse **<http://localhost:8082>**.

# Schritt 3: Labeln

## 3.1 Deine Annotator-ID eintragen

Trage oben im Feld **Annotator ID** einen kurzen Namen für dich ein, zum Beispiel deinen Vornamen (`anna`) oder `annotator1`. Erlaubt sind Buchstaben, Ziffern, `-` und `_`. Die ID wird an jeden Dateinamen angehängt. So bleibt erkennbar, welche Labels von wem stammen. Der Browser merkt sich die ID, du musst sie nur einmal eingeben.

**Wichtig:** Wenn ihr zu mehreren labelt, braucht jede Person eine eigene ID und arbeitet allein. Schaut euch die Labels der anderen erst an, wenn alle fertig sind. Nur so lässt sich später messen, wie gut ihr übereinstimmt.

## 3.2 Ein Prozessmodell öffnen

Klicke auf **Open .bpmn file** und wähle eine `.bpmn`-Datei aus. Das Diagramm erscheint. Die Felder **Model ID**, **Name** und **Export filename** werden automatisch aus dem Dateinamen ausgefüllt. *Model ID* und *Name* kannst du bei Bedarf ändern.

Mit `Strg` + Mausrad (Mac: `Cmd` + Mausrad) zoomst du, mit gedrückter Maustaste verschiebst du das Diagramm.

## 3.3 Aktivitäten bewerten

1. **Klicke auf eine Aktivität** (die rechteckigen Kästen) im Diagramm. Rechts erscheinen Name und ID der Aktivität.
2. Entscheide, ob die Aktivität mit RPA automatisierbar ist: **Automatable** oder **Not automatable**.
3. Ist sie automatisierbar, setze die Haken bei allen **Kriterien**, die sie erfüllt (mindestens eins, siehe Abschnitt 4).
4. Trage bei **Reason (optional)** kurz ein, warum du so entschieden hast. Das hilft später bei der Besprechung mit den anderen.
5. Klicke die nächste Aktivität an.

Die Farben im Diagramm zeigen deinen Fortschritt:

| Farbe | Bedeutung |
|---|---|
| Grün | als automatisierbar markiert |
| Grau | als nicht automatisierbar markiert |
| Weiß | noch nicht bewertet |

Über dem Diagramm siehst du, wie viele Aktivitäten du schon bewertet hast.

**Subprozesse** und Aufrufaktivitäten kannst du nicht anklicken. Sie werden nicht bewertet. Bewerte stattdessen die Aktivitäten **innerhalb** des Subprozesses. Bei aufgeklappten Subprozessen siehst du diese Aktivitäten direkt im Diagramm. Zugeklappte Subprozesse (Kasten mit einem kleinen **+**) öffnest du über das kleine Symbol am Kasten. Über die Leiste oben im Diagramm kommst du zurück zur Hauptebene.

## 3.4 Labels speichern

Klicke auf **Export labels.json**, wenn du alle Aktivitäten eines Modells bewertet hast. Die Datei landet in deinem **Download-Ordner** und heißt automatisch:

```
<Modellname>.labels.<Annotator-ID>.json
```

Zum Beispiel: `Urlaubsantrag.labels.anna.json`.

Hast du noch nicht alle Aktivitäten bewertet, fragt das Tool nach, ob du trotzdem speichern willst. Ohne Annotator-ID speichert das Tool nicht.

**Achtung, das Tool speichert nicht automatisch!** Deine Bewertungen gehen verloren, wenn du ein anderes Modell öffnest, die Seite neu lädst oder den Browser schließt. Exportiere deshalb **jedes Modell, sobald du damit fertig bist**. Ein späteres Weiterarbeiten an einer exportierten Datei ist nicht möglich, weil das Tool absichtlich keine vorhandenen Labels einliest.

Mit **Reset** löschst du alle Bewertungen des aktuell geöffneten Modells.

# Schritt 4: Regeln für das Labeling

Damit alle nach denselben Maßstäben bewerten, gelten diese Regeln.

**Grundlage ist nur das Prozessmodell.** Beurteile jede Aktivität nur anhand dessen, was im BPMN-Modell steht: Name der Aktivität, Pool und Lane, vorherige und nachfolgende Elemente, Datenobjekte, Nachrichtenflüsse und Anmerkungen. Nutze kein Wissen über den Prozess, das nicht im Modell steht.

**Entscheidungsregel:**

- Eine Aktivität ist **automatisierbar**, wenn sie mit RPA automatisiert werden kann. RPA bedeutet: Ein Software-Roboter führt die Tätigkeit aus, indem er wie ein Mensch über die Benutzeroberfläche mit vorhandenen Programmen arbeitet.
- Eine automatisierbare Aktivität erfüllt **mindestens ein** Kriterium. Sie darf auch mehrere erfüllen.
- Ist eine Aktivität **sehr allgemein beschrieben**, erschließe aus dem Kontext des Prozesses, ob sie mit RPA automatisierbar ist. **Ist das nicht möglich, markiere sie als nicht automatisierbar.**
- Ist eine Aktivität **eindeutig analog**, zum Beispiel handwerklich, körperlich oder handschriftlich, ist sie **nicht automatisierbar**.

**Die neun Kriterien nach Bédard et al.:**

1. Die Aktivität wird von einem Menschen mit einem oder mehreren Software-Systemen ausgeführt.
2. Die Aktivität beruht auf klar definierten, eindeutigen Regeln, die nur eine Auslegung zulassen.
3. Die Regeln der Aktivität sind stabil und ändern sich nicht.
4. Die Regeln werden bei der Ausführung streng durchgesetzt und sind keine bloßen Richtlinien.
5. Die Aktivität erfordert keine Kreativität und keine komplexe Interpretation.
6. Die Aktivität findet in einem stabilen Umfeld statt: Die Arbeit mit den Programmen ist klar festgelegt und vorhersehbar.
7. Die Aktivität verwendet strukturierte Daten (z. B. Formulare mit festen Feldern, Tabellen).
8. Alle Daten, die die Aktivität braucht, liegen digital vor.
9. Die Aktivität hat keine oder nur wenige Ausnahmen oder alternative Abläufe.

Setze ein Kriterium nur, wenn das Modell einen Hinweis darauf gibt. Bist du unsicher, lass es weg.

# Schritt 5: Labels für CORA vorbereiten

CORA liest pro Prozessmodell genau eine Label-Datei mit dem Namen `<Modellname>.labels.json`, also **ohne** Annotator-ID. Wenn mehrere Personen gelabelt haben:

1. Sammelt alle Label-Dateien und die `.bpmn`-Dateien in einem Ordner.
2. Besprecht die Aktivitäten, bei denen ihr unterschiedlich entschieden habt, und einigt euch auf eine gemeinsame Bewertung.
3. Erstellt für jedes Modell die gemeinsame Fassung, z. B. indem eine Person das Modell im Tool noch einmal mit den abgestimmten Bewertungen labelt.
4. Benennt diese Datei in `<Modellname>.labels.json` um.

Wie die Dateien in CORA verwendet werden, steht in der Anleitung zu CORA.

# Schritt 6: Das Tool beenden und wieder starten

**Beenden:** Im Terminal im Ordner labeling-tool:

```
docker compose down
```

**Wieder starten:** Docker Desktop öffnen, warten bis "Engine running" erscheint, dann im Ordner labeling-tool:

```
docker compose up -d
```

und im Browser <http://localhost:8082> öffnen.

# Wenn etwas nicht funktioniert

| Problem | Lösung |
|---|---|
| `docker` wird nicht erkannt | Docker Desktop ist nicht installiert oder nicht gestartet. Starte Docker Desktop und öffne danach ein **neues** Terminal. |
| "Cannot connect to the Docker daemon" oder "error during connect" | Docker Desktop starten und warten, bis "Engine running" angezeigt wird. |
| <http://localhost:8082> lädt nicht | Kurz warten und neu laden. Mit `docker compose ps` prüfen, ob der Container läuft. |
| "port is already allocated" beim Start | Ein anderes Programm nutzt Port 8082. Ändere in `compose.yaml` die Zeile `"8082:80"` zu `"8092:80"` und öffne dann <http://localhost:8092>. |
| "Could not parse this .bpmn file" | Die Datei ist kein gültiges BPMN 2.0. Exportiere das Modell erneut als **BPMN 2.0 XML**. Öffne keine `.labels.json`-Dateien im Tool. |
| Eine Aktivität lässt sich nicht anklicken | Es ist ein Subprozess oder kein Aktivitätskasten (z. B. ein Ereignis oder Gateway). Diese werden nicht bewertet. |
| Export fragt nach der Annotator-ID | Trage oben eine Annotator-ID ein und exportiere erneut. |
| Bewertungen sind weg | Die Seite wurde neu geladen oder ein anderes Modell geöffnet, bevor exportiert wurde. Das Modell muss neu gelabelt werden. |
| Docker meldet, dass Virtualisierung fehlt | Siehe Hinweis in Schritt 1 (Windows). |

Bei weiteren Fragen meldet euch per Mail bei <maurice.cordts@uni-ulm.de>.
