# BPMN Labeling Tool (Docker)

Graphical tool for labeling the activities of BPMN models with the nine RPA
feasibility criteria by Bedard et al. It produces `*.labels.<annotator>.json`
files in the format used by the evaluation pipeline (`rpa-potential`).

## Start

Requires Docker Desktop (or Docker Engine with Compose).

```bash
docker compose up --build -d
```

Open http://localhost:8082. Stop with `docker compose down`.

The tool runs entirely in the browser. BPMN files are opened from your own
computer and labels are downloaded as JSON files; nothing is uploaded to or
stored in the container.

## Usage

1. Enter your annotator ID once (e.g. `annotator1`). It is remembered by the
   browser and used for all exports.
2. Open a `.bpmn` file (not a `.labels.json` file).
3. Click an activity in the diagram, set "Automatable" to Yes/No, select the
   applicable criteria (1-9), and optionally add a reason.
4. Click "Export" to download the label file for this model. It is named
   `<model>.labels.<annotator-id>.json` automatically and also contains the
   annotator ID. Model ID and name are pre-filled from the BPMN file name and can
   be changed.
5. Repeat for every model.

The tool never loads existing labels, so every annotator labels blind.

## Without Docker

`index.html` expects bpmn-js under `vendor/`. To use the page without Docker,
replace the three `vendor/bpmn-js/...` references in `index.html` with the CDN
URLs `https://unpkg.com/bpmn-js@17.11.1/dist/...`.
